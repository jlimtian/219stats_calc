function root(a) {
    return Math.sqrt(a);
}
module.exports = root;