const divide = require('../divide');

test('divides 2 by 2 to equal 1', () => {
    expect(divide(2, 2)).toBe(1);
});